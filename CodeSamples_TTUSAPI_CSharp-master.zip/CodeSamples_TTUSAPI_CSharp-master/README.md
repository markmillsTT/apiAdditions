TTUS API Sample Applications in C#
==================================

For use with the Trading Technologies TTUS API (beta)

The repository contains a single Visual Studio 2010 solution which consists of 5 distinct projects, each illustrating a unique feature of the TTUS API.  For more information about the TTUS API please see http://developer.tradingtechnologies.com

The projects contained:

- UpdateCurrencyRates
- DisableGatewayAccess
- LockUserAccount
- UpdateUserCredit
- UpdateProductLimits
