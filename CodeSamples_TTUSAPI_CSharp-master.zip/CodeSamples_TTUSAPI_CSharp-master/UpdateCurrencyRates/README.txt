﻿README.txt
UpdateCurrencyRates (C#)
===============================================================================

Overview
-------------------------------------------------------------------------------

This example demonstrates using the TT US API to update exchange rates

Instructions
-------------------------------------------------------------------------------

1. Type TTUS username and password and click connect.
2. Select the two currencies that make up the desired exchange rate to update.
3. Type the rate of conversion in decimal form in the text box.
4. Click update button and look for success message in status bar.


TT US API Objects
-------------------------------------------------------------------------------

Currency
CurrencyExchangeRate
CurrencyExchangeRateProfile


Revisions
-------------------------------------------------------------------------------

Version:		1.0.0
Date Created:	06/07/2013
Notes:			None