﻿README.txt
DisableGatewayAccess (C#)
===============================================================================

Overview
-------------------------------------------------------------------------------

This example demonstrates using the TT US API to disable a users gateway access

Instructions
-------------------------------------------------------------------------------

1. Type TTUS username and password and click connect.
2. Select the user to disable access on.
3. Click disable button and look for success message in status bar.


TT US API Objects
-------------------------------------------------------------------------------

User
UserProfile
UserGatewayLogin
UserGatewayLoginProfile
UserGatewayCredential
UserGatewayCredentialProfile


Revisions
-------------------------------------------------------------------------------

Version:		1.0.0
Date Created:	06/07/2013
Notes:			None