﻿README.txt
LockUserAccount (C#)
===============================================================================

Overview
-------------------------------------------------------------------------------

This example demonstrates using the TT US API to disable an accounts trading access

Instructions
-------------------------------------------------------------------------------

1. Type TTUS username and password and click connect.
2. Select the account to disable trading on.
3. Click lock account button and look for success message in status bar.


TT US API Objects
-------------------------------------------------------------------------------

AccountGroup
AccountGroupProfile


Revisions
-------------------------------------------------------------------------------

Version:		1.0.0
Date Created:	06/07/2013
Notes:			None