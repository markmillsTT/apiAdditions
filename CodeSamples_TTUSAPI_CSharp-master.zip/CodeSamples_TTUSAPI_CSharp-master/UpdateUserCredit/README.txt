﻿README.txt
UpdateUserCredit (C#)
===============================================================================

Overview
-------------------------------------------------------------------------------

This example demonstrates using the TT US API to update a users credit

Instructions
-------------------------------------------------------------------------------

1. Type TTUS username and password and click connect.
2. Select the user to update credit on.
3. Enter the amount of credit for the user in the text box.
3. Click update button and look for status message.


TT US API Objects
-------------------------------------------------------------------------------

User
UserProfile


Revisions
-------------------------------------------------------------------------------

Version:		1.0.0
Date Created:	06/07/2013
Notes:			None