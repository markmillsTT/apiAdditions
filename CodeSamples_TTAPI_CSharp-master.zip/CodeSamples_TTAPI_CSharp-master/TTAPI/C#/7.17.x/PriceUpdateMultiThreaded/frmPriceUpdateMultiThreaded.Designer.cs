﻿namespace TTAPI_Samples
{
    partial class frmPriceUpdateMultiThreaded
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblNotProduction = new System.Windows.Forms.Label();
            this.lblWarning = new System.Windows.Forms.Label();
            this.gboInstrument_2 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtThreadID_2 = new System.Windows.Forms.TextBox();
            this.lblThreadID_2 = new System.Windows.Forms.Label();
            this.lblAskPrice_2 = new System.Windows.Forms.Label();
            this.lblExchange_2 = new System.Windows.Forms.Label();
            this.txtProduct_2 = new System.Windows.Forms.TextBox();
            this.txtProdType_2 = new System.Windows.Forms.TextBox();
            this.lblContract_2 = new System.Windows.Forms.Label();
            this.lblLastPrice_2 = new System.Windows.Forms.Label();
            this.txtLastPrice_2 = new System.Windows.Forms.TextBox();
            this.txtExchange_2 = new System.Windows.Forms.TextBox();
            this.lblProduct_2 = new System.Windows.Forms.Label();
            this.txtBidPrice_2 = new System.Windows.Forms.TextBox();
            this.lblBidPrice_2 = new System.Windows.Forms.Label();
            this.txtAskPrice_2 = new System.Windows.Forms.TextBox();
            this.txtContract_2 = new System.Windows.Forms.TextBox();
            this.lblProdType_2 = new System.Windows.Forms.Label();
            this.statusBar1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.mnuAbout = new System.Windows.Forms.MenuItem();
            this.gboInstrument_1 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtThreadID_1 = new System.Windows.Forms.TextBox();
            this.lblThreadID_1 = new System.Windows.Forms.Label();
            this.lblAskPrice_1 = new System.Windows.Forms.Label();
            this.lblExchange_1 = new System.Windows.Forms.Label();
            this.txtProduct_1 = new System.Windows.Forms.TextBox();
            this.txtProdType_1 = new System.Windows.Forms.TextBox();
            this.lblContract_1 = new System.Windows.Forms.Label();
            this.lblLastPrice_1 = new System.Windows.Forms.Label();
            this.txtLastPrice_1 = new System.Windows.Forms.TextBox();
            this.txtExchange_1 = new System.Windows.Forms.TextBox();
            this.lblProduct_1 = new System.Windows.Forms.Label();
            this.txtBidPrice_1 = new System.Windows.Forms.TextBox();
            this.lblBidPrice_1 = new System.Windows.Forms.Label();
            this.txtAskPrice_1 = new System.Windows.Forms.TextBox();
            this.txtContract_1 = new System.Windows.Forms.TextBox();
            this.lblProdType_1 = new System.Windows.Forms.Label();
            this.gboInstrument_3 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtThreadID_3 = new System.Windows.Forms.TextBox();
            this.lblThreadID_3 = new System.Windows.Forms.Label();
            this.lblAskPrice_3 = new System.Windows.Forms.Label();
            this.lblExchange_3 = new System.Windows.Forms.Label();
            this.txtProduct_3 = new System.Windows.Forms.TextBox();
            this.txtProdType_3 = new System.Windows.Forms.TextBox();
            this.lblContract_3 = new System.Windows.Forms.Label();
            this.lblLastPrice_3 = new System.Windows.Forms.Label();
            this.txtLastPrice_3 = new System.Windows.Forms.TextBox();
            this.txtExchange_3 = new System.Windows.Forms.TextBox();
            this.lblProduct_3 = new System.Windows.Forms.Label();
            this.txtBidPrice_3 = new System.Windows.Forms.TextBox();
            this.lblBidPrice_3 = new System.Windows.Forms.Label();
            this.txtAskPrice_3 = new System.Windows.Forms.TextBox();
            this.txtContract_3 = new System.Windows.Forms.TextBox();
            this.lblProdType_3 = new System.Windows.Forms.Label();
            this.gboInstrument_4 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtThreadID_4 = new System.Windows.Forms.TextBox();
            this.lblThreadID_4 = new System.Windows.Forms.Label();
            this.lblAskPrice_4 = new System.Windows.Forms.Label();
            this.lblExchange_4 = new System.Windows.Forms.Label();
            this.txtProduct_4 = new System.Windows.Forms.TextBox();
            this.txtProdType_4 = new System.Windows.Forms.TextBox();
            this.lblContract_4 = new System.Windows.Forms.Label();
            this.lblLastPrice_4 = new System.Windows.Forms.Label();
            this.txtLastPrice_4 = new System.Windows.Forms.TextBox();
            this.txtExchange_4 = new System.Windows.Forms.TextBox();
            this.lblProduct_4 = new System.Windows.Forms.Label();
            this.txtBidPrice_4 = new System.Windows.Forms.TextBox();
            this.lblBidPrice_4 = new System.Windows.Forms.Label();
            this.txtAskPrice_4 = new System.Windows.Forms.TextBox();
            this.txtContract_4 = new System.Windows.Forms.TextBox();
            this.lblProdType_4 = new System.Windows.Forms.Label();
            this.gboInstrument_2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.statusBar1.SuspendLayout();
            this.gboInstrument_1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.gboInstrument_3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.gboInstrument_4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNotProduction
            // 
            this.lblNotProduction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotProduction.Location = new System.Drawing.Point(12, 34);
            this.lblNotProduction.Name = "lblNotProduction";
            this.lblNotProduction.Size = new System.Drawing.Size(488, 14);
            this.lblNotProduction.TabIndex = 82;
            this.lblNotProduction.Text = "This sample is NOT to be used in production or during conformance testing.";
            this.lblNotProduction.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWarning
            // 
            this.lblWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.Location = new System.Drawing.Point(12, 9);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(488, 23);
            this.lblWarning.TabIndex = 81;
            this.lblWarning.Text = "WARNING!";
            this.lblWarning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gboInstrument_2
            // 
            this.gboInstrument_2.Controls.Add(this.panel1);
            this.gboInstrument_2.Controls.Add(this.lblAskPrice_2);
            this.gboInstrument_2.Controls.Add(this.lblExchange_2);
            this.gboInstrument_2.Controls.Add(this.txtProduct_2);
            this.gboInstrument_2.Controls.Add(this.txtProdType_2);
            this.gboInstrument_2.Controls.Add(this.lblContract_2);
            this.gboInstrument_2.Controls.Add(this.lblLastPrice_2);
            this.gboInstrument_2.Controls.Add(this.txtLastPrice_2);
            this.gboInstrument_2.Controls.Add(this.txtExchange_2);
            this.gboInstrument_2.Controls.Add(this.lblProduct_2);
            this.gboInstrument_2.Controls.Add(this.txtBidPrice_2);
            this.gboInstrument_2.Controls.Add(this.lblBidPrice_2);
            this.gboInstrument_2.Controls.Add(this.txtAskPrice_2);
            this.gboInstrument_2.Controls.Add(this.txtContract_2);
            this.gboInstrument_2.Controls.Add(this.lblProdType_2);
            this.gboInstrument_2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gboInstrument_2.Location = new System.Drawing.Point(259, 53);
            this.gboInstrument_2.Name = "gboInstrument_2";
            this.gboInstrument_2.Size = new System.Drawing.Size(241, 233);
            this.gboInstrument_2.TabIndex = 77;
            this.gboInstrument_2.TabStop = false;
            this.gboInstrument_2.Text = "Instrument 2";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtThreadID_2);
            this.panel1.Controls.Add(this.lblThreadID_2);
            this.panel1.Location = new System.Drawing.Point(6, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(229, 25);
            this.panel1.TabIndex = 71;
            // 
            // txtThreadID_2
            // 
            this.txtThreadID_2.BackColor = System.Drawing.Color.Gainsboro;
            this.txtThreadID_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtThreadID_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThreadID_2.Location = new System.Drawing.Point(89, 4);
            this.txtThreadID_2.Name = "txtThreadID_2";
            this.txtThreadID_2.Size = new System.Drawing.Size(126, 15);
            this.txtThreadID_2.TabIndex = 72;
            this.txtThreadID_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThreadID_2
            // 
            this.lblThreadID_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThreadID_2.Location = new System.Drawing.Point(3, 4);
            this.lblThreadID_2.Name = "lblThreadID_2";
            this.lblThreadID_2.Size = new System.Drawing.Size(77, 16);
            this.lblThreadID_2.TabIndex = 71;
            this.lblThreadID_2.Text = "Thread ID:";
            this.lblThreadID_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAskPrice_2
            // 
            this.lblAskPrice_2.Location = new System.Drawing.Point(10, 181);
            this.lblAskPrice_2.Name = "lblAskPrice_2";
            this.lblAskPrice_2.Size = new System.Drawing.Size(77, 16);
            this.lblAskPrice_2.TabIndex = 62;
            this.lblAskPrice_2.Text = "Ask Price:";
            this.lblAskPrice_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblExchange_2
            // 
            this.lblExchange_2.Location = new System.Drawing.Point(10, 51);
            this.lblExchange_2.Name = "lblExchange_2";
            this.lblExchange_2.Size = new System.Drawing.Size(77, 16);
            this.lblExchange_2.TabIndex = 57;
            this.lblExchange_2.Text = "Exchange:";
            this.lblExchange_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtProduct_2
            // 
            this.txtProduct_2.Location = new System.Drawing.Point(93, 74);
            this.txtProduct_2.Name = "txtProduct_2";
            this.txtProduct_2.Size = new System.Drawing.Size(129, 20);
            this.txtProduct_2.TabIndex = 65;
            // 
            // txtProdType_2
            // 
            this.txtProdType_2.Location = new System.Drawing.Point(93, 98);
            this.txtProdType_2.Name = "txtProdType_2";
            this.txtProdType_2.Size = new System.Drawing.Size(129, 20);
            this.txtProdType_2.TabIndex = 66;
            // 
            // lblContract_2
            // 
            this.lblContract_2.Location = new System.Drawing.Point(10, 123);
            this.lblContract_2.Name = "lblContract_2";
            this.lblContract_2.Size = new System.Drawing.Size(77, 16);
            this.lblContract_2.TabIndex = 60;
            this.lblContract_2.Text = "Contract:";
            this.lblContract_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLastPrice_2
            // 
            this.lblLastPrice_2.Location = new System.Drawing.Point(10, 205);
            this.lblLastPrice_2.Name = "lblLastPrice_2";
            this.lblLastPrice_2.Size = new System.Drawing.Size(77, 16);
            this.lblLastPrice_2.TabIndex = 63;
            this.lblLastPrice_2.Text = "Last Price:";
            this.lblLastPrice_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtLastPrice_2
            // 
            this.txtLastPrice_2.Location = new System.Drawing.Point(93, 204);
            this.txtLastPrice_2.Name = "txtLastPrice_2";
            this.txtLastPrice_2.Size = new System.Drawing.Size(129, 20);
            this.txtLastPrice_2.TabIndex = 70;
            // 
            // txtExchange_2
            // 
            this.txtExchange_2.Location = new System.Drawing.Point(93, 50);
            this.txtExchange_2.Name = "txtExchange_2";
            this.txtExchange_2.Size = new System.Drawing.Size(129, 20);
            this.txtExchange_2.TabIndex = 64;
            // 
            // lblProduct_2
            // 
            this.lblProduct_2.Location = new System.Drawing.Point(10, 75);
            this.lblProduct_2.Name = "lblProduct_2";
            this.lblProduct_2.Size = new System.Drawing.Size(77, 16);
            this.lblProduct_2.TabIndex = 58;
            this.lblProduct_2.Text = "Product:";
            this.lblProduct_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtBidPrice_2
            // 
            this.txtBidPrice_2.Location = new System.Drawing.Point(93, 156);
            this.txtBidPrice_2.Name = "txtBidPrice_2";
            this.txtBidPrice_2.Size = new System.Drawing.Size(129, 20);
            this.txtBidPrice_2.TabIndex = 68;
            // 
            // lblBidPrice_2
            // 
            this.lblBidPrice_2.Location = new System.Drawing.Point(10, 157);
            this.lblBidPrice_2.Name = "lblBidPrice_2";
            this.lblBidPrice_2.Size = new System.Drawing.Size(77, 16);
            this.lblBidPrice_2.TabIndex = 61;
            this.lblBidPrice_2.Text = "Bid Price:";
            this.lblBidPrice_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtAskPrice_2
            // 
            this.txtAskPrice_2.Location = new System.Drawing.Point(93, 180);
            this.txtAskPrice_2.Name = "txtAskPrice_2";
            this.txtAskPrice_2.Size = new System.Drawing.Size(129, 20);
            this.txtAskPrice_2.TabIndex = 69;
            // 
            // txtContract_2
            // 
            this.txtContract_2.Location = new System.Drawing.Point(93, 122);
            this.txtContract_2.Name = "txtContract_2";
            this.txtContract_2.Size = new System.Drawing.Size(129, 20);
            this.txtContract_2.TabIndex = 67;
            // 
            // lblProdType_2
            // 
            this.lblProdType_2.Location = new System.Drawing.Point(10, 99);
            this.lblProdType_2.Name = "lblProdType_2";
            this.lblProdType_2.Size = new System.Drawing.Size(77, 16);
            this.lblProdType_2.TabIndex = 59;
            this.lblProdType_2.Text = "Product Type:";
            this.lblProdType_2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // statusBar1
            // 
            this.statusBar1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusBar1.Location = new System.Drawing.Point(0, 534);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(510, 22);
            this.statusBar1.TabIndex = 83;
            this.statusBar1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(466, 17);
            this.toolStripStatusLabel1.Text = "Drag and Drop multiple instruments from the Market Grid in X_TRADER to this windo" +
    "w.";
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuAbout});
            // 
            // mnuAbout
            // 
            this.mnuAbout.Index = 0;
            this.mnuAbout.Text = "About...";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // gboInstrument_1
            // 
            this.gboInstrument_1.Controls.Add(this.panel2);
            this.gboInstrument_1.Controls.Add(this.lblAskPrice_1);
            this.gboInstrument_1.Controls.Add(this.lblExchange_1);
            this.gboInstrument_1.Controls.Add(this.txtProduct_1);
            this.gboInstrument_1.Controls.Add(this.txtProdType_1);
            this.gboInstrument_1.Controls.Add(this.lblContract_1);
            this.gboInstrument_1.Controls.Add(this.lblLastPrice_1);
            this.gboInstrument_1.Controls.Add(this.txtLastPrice_1);
            this.gboInstrument_1.Controls.Add(this.txtExchange_1);
            this.gboInstrument_1.Controls.Add(this.lblProduct_1);
            this.gboInstrument_1.Controls.Add(this.txtBidPrice_1);
            this.gboInstrument_1.Controls.Add(this.lblBidPrice_1);
            this.gboInstrument_1.Controls.Add(this.txtAskPrice_1);
            this.gboInstrument_1.Controls.Add(this.txtContract_1);
            this.gboInstrument_1.Controls.Add(this.lblProdType_1);
            this.gboInstrument_1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gboInstrument_1.Location = new System.Drawing.Point(12, 53);
            this.gboInstrument_1.Name = "gboInstrument_1";
            this.gboInstrument_1.Size = new System.Drawing.Size(241, 233);
            this.gboInstrument_1.TabIndex = 78;
            this.gboInstrument_1.TabStop = false;
            this.gboInstrument_1.Text = "Instrument 1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtThreadID_1);
            this.panel2.Controls.Add(this.lblThreadID_1);
            this.panel2.Location = new System.Drawing.Point(6, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(229, 25);
            this.panel2.TabIndex = 71;
            // 
            // txtThreadID_1
            // 
            this.txtThreadID_1.BackColor = System.Drawing.Color.Gainsboro;
            this.txtThreadID_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtThreadID_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThreadID_1.Location = new System.Drawing.Point(89, 4);
            this.txtThreadID_1.Name = "txtThreadID_1";
            this.txtThreadID_1.Size = new System.Drawing.Size(126, 15);
            this.txtThreadID_1.TabIndex = 72;
            this.txtThreadID_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThreadID_1
            // 
            this.lblThreadID_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThreadID_1.Location = new System.Drawing.Point(3, 4);
            this.lblThreadID_1.Name = "lblThreadID_1";
            this.lblThreadID_1.Size = new System.Drawing.Size(77, 16);
            this.lblThreadID_1.TabIndex = 71;
            this.lblThreadID_1.Text = "Thread ID:";
            this.lblThreadID_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAskPrice_1
            // 
            this.lblAskPrice_1.Location = new System.Drawing.Point(10, 181);
            this.lblAskPrice_1.Name = "lblAskPrice_1";
            this.lblAskPrice_1.Size = new System.Drawing.Size(77, 16);
            this.lblAskPrice_1.TabIndex = 62;
            this.lblAskPrice_1.Text = "Ask Price:";
            this.lblAskPrice_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblExchange_1
            // 
            this.lblExchange_1.Location = new System.Drawing.Point(10, 51);
            this.lblExchange_1.Name = "lblExchange_1";
            this.lblExchange_1.Size = new System.Drawing.Size(77, 16);
            this.lblExchange_1.TabIndex = 57;
            this.lblExchange_1.Text = "Exchange:";
            this.lblExchange_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtProduct_1
            // 
            this.txtProduct_1.Location = new System.Drawing.Point(93, 74);
            this.txtProduct_1.Name = "txtProduct_1";
            this.txtProduct_1.Size = new System.Drawing.Size(129, 20);
            this.txtProduct_1.TabIndex = 65;
            // 
            // txtProdType_1
            // 
            this.txtProdType_1.Location = new System.Drawing.Point(93, 98);
            this.txtProdType_1.Name = "txtProdType_1";
            this.txtProdType_1.Size = new System.Drawing.Size(129, 20);
            this.txtProdType_1.TabIndex = 66;
            // 
            // lblContract_1
            // 
            this.lblContract_1.Location = new System.Drawing.Point(10, 123);
            this.lblContract_1.Name = "lblContract_1";
            this.lblContract_1.Size = new System.Drawing.Size(77, 16);
            this.lblContract_1.TabIndex = 60;
            this.lblContract_1.Text = "Contract:";
            this.lblContract_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLastPrice_1
            // 
            this.lblLastPrice_1.Location = new System.Drawing.Point(10, 205);
            this.lblLastPrice_1.Name = "lblLastPrice_1";
            this.lblLastPrice_1.Size = new System.Drawing.Size(77, 16);
            this.lblLastPrice_1.TabIndex = 63;
            this.lblLastPrice_1.Text = "Last Price:";
            this.lblLastPrice_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtLastPrice_1
            // 
            this.txtLastPrice_1.Location = new System.Drawing.Point(93, 204);
            this.txtLastPrice_1.Name = "txtLastPrice_1";
            this.txtLastPrice_1.Size = new System.Drawing.Size(129, 20);
            this.txtLastPrice_1.TabIndex = 70;
            // 
            // txtExchange_1
            // 
            this.txtExchange_1.Location = new System.Drawing.Point(93, 50);
            this.txtExchange_1.Name = "txtExchange_1";
            this.txtExchange_1.Size = new System.Drawing.Size(129, 20);
            this.txtExchange_1.TabIndex = 64;
            // 
            // lblProduct_1
            // 
            this.lblProduct_1.Location = new System.Drawing.Point(10, 75);
            this.lblProduct_1.Name = "lblProduct_1";
            this.lblProduct_1.Size = new System.Drawing.Size(77, 16);
            this.lblProduct_1.TabIndex = 58;
            this.lblProduct_1.Text = "Product:";
            this.lblProduct_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtBidPrice_1
            // 
            this.txtBidPrice_1.Location = new System.Drawing.Point(93, 156);
            this.txtBidPrice_1.Name = "txtBidPrice_1";
            this.txtBidPrice_1.Size = new System.Drawing.Size(129, 20);
            this.txtBidPrice_1.TabIndex = 68;
            // 
            // lblBidPrice_1
            // 
            this.lblBidPrice_1.Location = new System.Drawing.Point(10, 157);
            this.lblBidPrice_1.Name = "lblBidPrice_1";
            this.lblBidPrice_1.Size = new System.Drawing.Size(77, 16);
            this.lblBidPrice_1.TabIndex = 61;
            this.lblBidPrice_1.Text = "Bid Price:";
            this.lblBidPrice_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtAskPrice_1
            // 
            this.txtAskPrice_1.Location = new System.Drawing.Point(93, 180);
            this.txtAskPrice_1.Name = "txtAskPrice_1";
            this.txtAskPrice_1.Size = new System.Drawing.Size(129, 20);
            this.txtAskPrice_1.TabIndex = 69;
            // 
            // txtContract_1
            // 
            this.txtContract_1.Location = new System.Drawing.Point(93, 122);
            this.txtContract_1.Name = "txtContract_1";
            this.txtContract_1.Size = new System.Drawing.Size(129, 20);
            this.txtContract_1.TabIndex = 67;
            // 
            // lblProdType_1
            // 
            this.lblProdType_1.Location = new System.Drawing.Point(10, 99);
            this.lblProdType_1.Name = "lblProdType_1";
            this.lblProdType_1.Size = new System.Drawing.Size(77, 16);
            this.lblProdType_1.TabIndex = 59;
            this.lblProdType_1.Text = "Product Type:";
            this.lblProdType_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gboInstrument_3
            // 
            this.gboInstrument_3.Controls.Add(this.panel3);
            this.gboInstrument_3.Controls.Add(this.lblAskPrice_3);
            this.gboInstrument_3.Controls.Add(this.lblExchange_3);
            this.gboInstrument_3.Controls.Add(this.txtProduct_3);
            this.gboInstrument_3.Controls.Add(this.txtProdType_3);
            this.gboInstrument_3.Controls.Add(this.lblContract_3);
            this.gboInstrument_3.Controls.Add(this.lblLastPrice_3);
            this.gboInstrument_3.Controls.Add(this.txtLastPrice_3);
            this.gboInstrument_3.Controls.Add(this.txtExchange_3);
            this.gboInstrument_3.Controls.Add(this.lblProduct_3);
            this.gboInstrument_3.Controls.Add(this.txtBidPrice_3);
            this.gboInstrument_3.Controls.Add(this.lblBidPrice_3);
            this.gboInstrument_3.Controls.Add(this.txtAskPrice_3);
            this.gboInstrument_3.Controls.Add(this.txtContract_3);
            this.gboInstrument_3.Controls.Add(this.lblProdType_3);
            this.gboInstrument_3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gboInstrument_3.Location = new System.Drawing.Point(12, 292);
            this.gboInstrument_3.Name = "gboInstrument_3";
            this.gboInstrument_3.Size = new System.Drawing.Size(241, 233);
            this.gboInstrument_3.TabIndex = 80;
            this.gboInstrument_3.TabStop = false;
            this.gboInstrument_3.Text = "Instrument 3";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.txtThreadID_3);
            this.panel3.Controls.Add(this.lblThreadID_3);
            this.panel3.Location = new System.Drawing.Point(6, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(229, 25);
            this.panel3.TabIndex = 71;
            // 
            // txtThreadID_3
            // 
            this.txtThreadID_3.BackColor = System.Drawing.Color.Gainsboro;
            this.txtThreadID_3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtThreadID_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThreadID_3.Location = new System.Drawing.Point(89, 4);
            this.txtThreadID_3.Name = "txtThreadID_3";
            this.txtThreadID_3.Size = new System.Drawing.Size(126, 15);
            this.txtThreadID_3.TabIndex = 72;
            this.txtThreadID_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThreadID_3
            // 
            this.lblThreadID_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThreadID_3.Location = new System.Drawing.Point(3, 4);
            this.lblThreadID_3.Name = "lblThreadID_3";
            this.lblThreadID_3.Size = new System.Drawing.Size(77, 16);
            this.lblThreadID_3.TabIndex = 71;
            this.lblThreadID_3.Text = "Thread ID:";
            this.lblThreadID_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAskPrice_3
            // 
            this.lblAskPrice_3.Location = new System.Drawing.Point(10, 181);
            this.lblAskPrice_3.Name = "lblAskPrice_3";
            this.lblAskPrice_3.Size = new System.Drawing.Size(77, 16);
            this.lblAskPrice_3.TabIndex = 62;
            this.lblAskPrice_3.Text = "Ask Price:";
            this.lblAskPrice_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblExchange_3
            // 
            this.lblExchange_3.Location = new System.Drawing.Point(10, 51);
            this.lblExchange_3.Name = "lblExchange_3";
            this.lblExchange_3.Size = new System.Drawing.Size(77, 16);
            this.lblExchange_3.TabIndex = 57;
            this.lblExchange_3.Text = "Exchange:";
            this.lblExchange_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtProduct_3
            // 
            this.txtProduct_3.Location = new System.Drawing.Point(93, 74);
            this.txtProduct_3.Name = "txtProduct_3";
            this.txtProduct_3.Size = new System.Drawing.Size(129, 20);
            this.txtProduct_3.TabIndex = 65;
            // 
            // txtProdType_3
            // 
            this.txtProdType_3.Location = new System.Drawing.Point(93, 98);
            this.txtProdType_3.Name = "txtProdType_3";
            this.txtProdType_3.Size = new System.Drawing.Size(129, 20);
            this.txtProdType_3.TabIndex = 66;
            // 
            // lblContract_3
            // 
            this.lblContract_3.Location = new System.Drawing.Point(10, 123);
            this.lblContract_3.Name = "lblContract_3";
            this.lblContract_3.Size = new System.Drawing.Size(77, 16);
            this.lblContract_3.TabIndex = 60;
            this.lblContract_3.Text = "Contract:";
            this.lblContract_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLastPrice_3
            // 
            this.lblLastPrice_3.Location = new System.Drawing.Point(10, 205);
            this.lblLastPrice_3.Name = "lblLastPrice_3";
            this.lblLastPrice_3.Size = new System.Drawing.Size(77, 16);
            this.lblLastPrice_3.TabIndex = 63;
            this.lblLastPrice_3.Text = "Last Price:";
            this.lblLastPrice_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtLastPrice_3
            // 
            this.txtLastPrice_3.Location = new System.Drawing.Point(93, 204);
            this.txtLastPrice_3.Name = "txtLastPrice_3";
            this.txtLastPrice_3.Size = new System.Drawing.Size(129, 20);
            this.txtLastPrice_3.TabIndex = 70;
            // 
            // txtExchange_3
            // 
            this.txtExchange_3.Location = new System.Drawing.Point(93, 50);
            this.txtExchange_3.Name = "txtExchange_3";
            this.txtExchange_3.Size = new System.Drawing.Size(129, 20);
            this.txtExchange_3.TabIndex = 64;
            // 
            // lblProduct_3
            // 
            this.lblProduct_3.Location = new System.Drawing.Point(10, 75);
            this.lblProduct_3.Name = "lblProduct_3";
            this.lblProduct_3.Size = new System.Drawing.Size(77, 16);
            this.lblProduct_3.TabIndex = 58;
            this.lblProduct_3.Text = "Product:";
            this.lblProduct_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtBidPrice_3
            // 
            this.txtBidPrice_3.Location = new System.Drawing.Point(93, 156);
            this.txtBidPrice_3.Name = "txtBidPrice_3";
            this.txtBidPrice_3.Size = new System.Drawing.Size(129, 20);
            this.txtBidPrice_3.TabIndex = 68;
            // 
            // lblBidPrice_3
            // 
            this.lblBidPrice_3.Location = new System.Drawing.Point(10, 157);
            this.lblBidPrice_3.Name = "lblBidPrice_3";
            this.lblBidPrice_3.Size = new System.Drawing.Size(77, 16);
            this.lblBidPrice_3.TabIndex = 61;
            this.lblBidPrice_3.Text = "Bid Price:";
            this.lblBidPrice_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtAskPrice_3
            // 
            this.txtAskPrice_3.Location = new System.Drawing.Point(93, 180);
            this.txtAskPrice_3.Name = "txtAskPrice_3";
            this.txtAskPrice_3.Size = new System.Drawing.Size(129, 20);
            this.txtAskPrice_3.TabIndex = 69;
            // 
            // txtContract_3
            // 
            this.txtContract_3.Location = new System.Drawing.Point(93, 122);
            this.txtContract_3.Name = "txtContract_3";
            this.txtContract_3.Size = new System.Drawing.Size(129, 20);
            this.txtContract_3.TabIndex = 67;
            // 
            // lblProdType_3
            // 
            this.lblProdType_3.Location = new System.Drawing.Point(10, 99);
            this.lblProdType_3.Name = "lblProdType_3";
            this.lblProdType_3.Size = new System.Drawing.Size(77, 16);
            this.lblProdType_3.TabIndex = 59;
            this.lblProdType_3.Text = "Product Type:";
            this.lblProdType_3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gboInstrument_4
            // 
            this.gboInstrument_4.Controls.Add(this.panel4);
            this.gboInstrument_4.Controls.Add(this.lblAskPrice_4);
            this.gboInstrument_4.Controls.Add(this.lblExchange_4);
            this.gboInstrument_4.Controls.Add(this.txtProduct_4);
            this.gboInstrument_4.Controls.Add(this.txtProdType_4);
            this.gboInstrument_4.Controls.Add(this.lblContract_4);
            this.gboInstrument_4.Controls.Add(this.lblLastPrice_4);
            this.gboInstrument_4.Controls.Add(this.txtLastPrice_4);
            this.gboInstrument_4.Controls.Add(this.txtExchange_4);
            this.gboInstrument_4.Controls.Add(this.lblProduct_4);
            this.gboInstrument_4.Controls.Add(this.txtBidPrice_4);
            this.gboInstrument_4.Controls.Add(this.lblBidPrice_4);
            this.gboInstrument_4.Controls.Add(this.txtAskPrice_4);
            this.gboInstrument_4.Controls.Add(this.txtContract_4);
            this.gboInstrument_4.Controls.Add(this.lblProdType_4);
            this.gboInstrument_4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gboInstrument_4.Location = new System.Drawing.Point(259, 292);
            this.gboInstrument_4.Name = "gboInstrument_4";
            this.gboInstrument_4.Size = new System.Drawing.Size(241, 233);
            this.gboInstrument_4.TabIndex = 79;
            this.gboInstrument_4.TabStop = false;
            this.gboInstrument_4.Text = "Instrument 4";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.txtThreadID_4);
            this.panel4.Controls.Add(this.lblThreadID_4);
            this.panel4.Location = new System.Drawing.Point(6, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(229, 25);
            this.panel4.TabIndex = 71;
            // 
            // txtThreadID_4
            // 
            this.txtThreadID_4.BackColor = System.Drawing.Color.Gainsboro;
            this.txtThreadID_4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtThreadID_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThreadID_4.Location = new System.Drawing.Point(89, 4);
            this.txtThreadID_4.Name = "txtThreadID_4";
            this.txtThreadID_4.Size = new System.Drawing.Size(126, 15);
            this.txtThreadID_4.TabIndex = 72;
            this.txtThreadID_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThreadID_4
            // 
            this.lblThreadID_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThreadID_4.Location = new System.Drawing.Point(3, 4);
            this.lblThreadID_4.Name = "lblThreadID_4";
            this.lblThreadID_4.Size = new System.Drawing.Size(77, 16);
            this.lblThreadID_4.TabIndex = 71;
            this.lblThreadID_4.Text = "Thread ID:";
            this.lblThreadID_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAskPrice_4
            // 
            this.lblAskPrice_4.Location = new System.Drawing.Point(10, 181);
            this.lblAskPrice_4.Name = "lblAskPrice_4";
            this.lblAskPrice_4.Size = new System.Drawing.Size(77, 16);
            this.lblAskPrice_4.TabIndex = 62;
            this.lblAskPrice_4.Text = "Ask Price:";
            this.lblAskPrice_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblExchange_4
            // 
            this.lblExchange_4.Location = new System.Drawing.Point(10, 51);
            this.lblExchange_4.Name = "lblExchange_4";
            this.lblExchange_4.Size = new System.Drawing.Size(77, 16);
            this.lblExchange_4.TabIndex = 57;
            this.lblExchange_4.Text = "Exchange:";
            this.lblExchange_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtProduct_4
            // 
            this.txtProduct_4.Location = new System.Drawing.Point(93, 74);
            this.txtProduct_4.Name = "txtProduct_4";
            this.txtProduct_4.Size = new System.Drawing.Size(129, 20);
            this.txtProduct_4.TabIndex = 65;
            // 
            // txtProdType_4
            // 
            this.txtProdType_4.Location = new System.Drawing.Point(93, 98);
            this.txtProdType_4.Name = "txtProdType_4";
            this.txtProdType_4.Size = new System.Drawing.Size(129, 20);
            this.txtProdType_4.TabIndex = 66;
            // 
            // lblContract_4
            // 
            this.lblContract_4.Location = new System.Drawing.Point(10, 123);
            this.lblContract_4.Name = "lblContract_4";
            this.lblContract_4.Size = new System.Drawing.Size(77, 16);
            this.lblContract_4.TabIndex = 60;
            this.lblContract_4.Text = "Contract:";
            this.lblContract_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLastPrice_4
            // 
            this.lblLastPrice_4.Location = new System.Drawing.Point(10, 205);
            this.lblLastPrice_4.Name = "lblLastPrice_4";
            this.lblLastPrice_4.Size = new System.Drawing.Size(77, 16);
            this.lblLastPrice_4.TabIndex = 63;
            this.lblLastPrice_4.Text = "Last Price:";
            this.lblLastPrice_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtLastPrice_4
            // 
            this.txtLastPrice_4.Location = new System.Drawing.Point(93, 204);
            this.txtLastPrice_4.Name = "txtLastPrice_4";
            this.txtLastPrice_4.Size = new System.Drawing.Size(129, 20);
            this.txtLastPrice_4.TabIndex = 70;
            // 
            // txtExchange_4
            // 
            this.txtExchange_4.Location = new System.Drawing.Point(93, 50);
            this.txtExchange_4.Name = "txtExchange_4";
            this.txtExchange_4.Size = new System.Drawing.Size(129, 20);
            this.txtExchange_4.TabIndex = 64;
            // 
            // lblProduct_4
            // 
            this.lblProduct_4.Location = new System.Drawing.Point(10, 75);
            this.lblProduct_4.Name = "lblProduct_4";
            this.lblProduct_4.Size = new System.Drawing.Size(77, 16);
            this.lblProduct_4.TabIndex = 58;
            this.lblProduct_4.Text = "Product:";
            this.lblProduct_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtBidPrice_4
            // 
            this.txtBidPrice_4.Location = new System.Drawing.Point(93, 156);
            this.txtBidPrice_4.Name = "txtBidPrice_4";
            this.txtBidPrice_4.Size = new System.Drawing.Size(129, 20);
            this.txtBidPrice_4.TabIndex = 68;
            // 
            // lblBidPrice_4
            // 
            this.lblBidPrice_4.Location = new System.Drawing.Point(10, 157);
            this.lblBidPrice_4.Name = "lblBidPrice_4";
            this.lblBidPrice_4.Size = new System.Drawing.Size(77, 16);
            this.lblBidPrice_4.TabIndex = 61;
            this.lblBidPrice_4.Text = "Bid Price:";
            this.lblBidPrice_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtAskPrice_4
            // 
            this.txtAskPrice_4.Location = new System.Drawing.Point(93, 180);
            this.txtAskPrice_4.Name = "txtAskPrice_4";
            this.txtAskPrice_4.Size = new System.Drawing.Size(129, 20);
            this.txtAskPrice_4.TabIndex = 69;
            // 
            // txtContract_4
            // 
            this.txtContract_4.Location = new System.Drawing.Point(93, 122);
            this.txtContract_4.Name = "txtContract_4";
            this.txtContract_4.Size = new System.Drawing.Size(129, 20);
            this.txtContract_4.TabIndex = 67;
            // 
            // lblProdType_4
            // 
            this.lblProdType_4.Location = new System.Drawing.Point(10, 99);
            this.lblProdType_4.Name = "lblProdType_4";
            this.lblProdType_4.Size = new System.Drawing.Size(77, 16);
            this.lblProdType_4.TabIndex = 59;
            this.lblProdType_4.Text = "Product Type:";
            this.lblProdType_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmPriceUpdateMultiThreaded
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 556);
            this.Controls.Add(this.gboInstrument_3);
            this.Controls.Add(this.gboInstrument_1);
            this.Controls.Add(this.gboInstrument_4);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.lblNotProduction);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.gboInstrument_2);
            this.Enabled = false;
            this.Menu = this.mainMenu1;
            this.Name = "frmPriceUpdateMultiThreaded";
            this.Text = "PriceUpdateMultiThreaded";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.frmPriceUpdateMultiThreaded_DragDrop);
            this.DragOver += new System.Windows.Forms.DragEventHandler(this.frmPriceUpdateMultiThreaded_DragOver);
            this.gboInstrument_2.ResumeLayout(false);
            this.gboInstrument_2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusBar1.ResumeLayout(false);
            this.statusBar1.PerformLayout();
            this.gboInstrument_1.ResumeLayout(false);
            this.gboInstrument_1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.gboInstrument_3.ResumeLayout(false);
            this.gboInstrument_3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.gboInstrument_4.ResumeLayout(false);
            this.gboInstrument_4.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNotProduction;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.GroupBox gboInstrument_2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtThreadID_2;
        private System.Windows.Forms.Label lblThreadID_2;
        private System.Windows.Forms.Label lblAskPrice_2;
        private System.Windows.Forms.Label lblExchange_2;
        private System.Windows.Forms.TextBox txtProduct_2;
        private System.Windows.Forms.TextBox txtProdType_2;
        private System.Windows.Forms.Label lblContract_2;
        private System.Windows.Forms.Label lblLastPrice_2;
        private System.Windows.Forms.TextBox txtLastPrice_2;
        private System.Windows.Forms.TextBox txtExchange_2;
        private System.Windows.Forms.Label lblProduct_2;
        private System.Windows.Forms.TextBox txtBidPrice_2;
        private System.Windows.Forms.Label lblBidPrice_2;
        private System.Windows.Forms.TextBox txtAskPrice_2;
        private System.Windows.Forms.TextBox txtContract_2;
        private System.Windows.Forms.Label lblProdType_2;
        private System.Windows.Forms.StatusStrip statusBar1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem mnuAbout;
        private System.Windows.Forms.GroupBox gboInstrument_1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtThreadID_1;
        private System.Windows.Forms.Label lblThreadID_1;
        private System.Windows.Forms.Label lblAskPrice_1;
        private System.Windows.Forms.Label lblExchange_1;
        private System.Windows.Forms.TextBox txtProduct_1;
        private System.Windows.Forms.TextBox txtProdType_1;
        private System.Windows.Forms.Label lblContract_1;
        private System.Windows.Forms.Label lblLastPrice_1;
        private System.Windows.Forms.TextBox txtLastPrice_1;
        private System.Windows.Forms.TextBox txtExchange_1;
        private System.Windows.Forms.Label lblProduct_1;
        private System.Windows.Forms.TextBox txtBidPrice_1;
        private System.Windows.Forms.Label lblBidPrice_1;
        private System.Windows.Forms.TextBox txtAskPrice_1;
        private System.Windows.Forms.TextBox txtContract_1;
        private System.Windows.Forms.Label lblProdType_1;
        private System.Windows.Forms.GroupBox gboInstrument_3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtThreadID_3;
        private System.Windows.Forms.Label lblThreadID_3;
        private System.Windows.Forms.Label lblAskPrice_3;
        private System.Windows.Forms.Label lblExchange_3;
        private System.Windows.Forms.TextBox txtProduct_3;
        private System.Windows.Forms.TextBox txtProdType_3;
        private System.Windows.Forms.Label lblContract_3;
        private System.Windows.Forms.Label lblLastPrice_3;
        private System.Windows.Forms.TextBox txtLastPrice_3;
        private System.Windows.Forms.TextBox txtExchange_3;
        private System.Windows.Forms.Label lblProduct_3;
        private System.Windows.Forms.TextBox txtBidPrice_3;
        private System.Windows.Forms.Label lblBidPrice_3;
        private System.Windows.Forms.TextBox txtAskPrice_3;
        private System.Windows.Forms.TextBox txtContract_3;
        private System.Windows.Forms.Label lblProdType_3;
        private System.Windows.Forms.GroupBox gboInstrument_4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtThreadID_4;
        private System.Windows.Forms.Label lblThreadID_4;
        private System.Windows.Forms.Label lblAskPrice_4;
        private System.Windows.Forms.Label lblExchange_4;
        private System.Windows.Forms.TextBox txtProduct_4;
        private System.Windows.Forms.TextBox txtProdType_4;
        private System.Windows.Forms.Label lblContract_4;
        private System.Windows.Forms.Label lblLastPrice_4;
        private System.Windows.Forms.TextBox txtLastPrice_4;
        private System.Windows.Forms.TextBox txtExchange_4;
        private System.Windows.Forms.Label lblProduct_4;
        private System.Windows.Forms.TextBox txtBidPrice_4;
        private System.Windows.Forms.Label lblBidPrice_4;
        private System.Windows.Forms.TextBox txtAskPrice_4;
        private System.Windows.Forms.TextBox txtContract_4;
        private System.Windows.Forms.Label lblProdType_4;
    }
}

