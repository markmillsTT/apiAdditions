﻿README.txt
MarketExplorer (C#)
===============================================================================

Overview
-------------------------------------------------------------------------------

This example demonstrates using the TT API to receive available exchanges, 
products, and contract definitions.


Instructions
-------------------------------------------------------------------------------

1. The available exchanges will load when the application is ran.
2. Select an exchange from the list
3. Select a product type from the list - products should now appear.


TT API Objects
-------------------------------------------------------------------------------

ProductCatalogSubscription


Revisions
-------------------------------------------------------------------------------

Version:		1.0.0
Date Created:	05/15/2012
Notes:			None

Version:		1.1.0
Date Created:	01/18/2013
Notes:			Updated for GitHub.

Version:		7.17.0
Date Created:	10/02/2013
Notes:			Updated for TT API 7.17.  Changed initialization
				and shutdown code. 