README.txt
HotKey (C#)
===============================================================================


Overview
-------------------------------------------------------------------------------

This example demonstrates using the XTAPI capture a specific keystroke from the
users keyboard.


Instructions
-------------------------------------------------------------------------------

1. Press the b, s, CTRL-d, or F1 key.
2. A message will be displayed in the text box.



XTAPI Objects
-------------------------------------------------------------------------------

TTHotKey


Revisions
-------------------------------------------------------------------------------

Version:		1.1.0
Date Created:	06/29/2010
Notes:			None

Version:		1.2.1
Date Created:	01/17/2013
Notes:			Updated for GitHub.   Added support for non-ASCII characters.