//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OrderSelector.rc
//
#define IDD_ORDERSELECTOR_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_EXCHANGEBOX                 1000
#define IDC_PRODUCTBOX                  1001
#define IDC_PRODTYPEBOX                 1002
#define IDC_CONTRACTBOX                 1003
#define IDC_CONNECT                     1004
#define IDC_CONTRACTBOX2                1004
#define IDC_PRICEBOX                    1005
#define IDC_QUANTITYBOX                 1006
#define IDC_BUYBUTTON                   1007
#define IDC_SELLBUTTON                  1008
#define IDC_BIDBOX                      1009
#define IDC_EXCHANGEBOX2                1009
#define IDC_ASKBOX                      1010
#define IDC_LTPBOX                      1011
#define IDC_CHANGEBOX                   1012
#define IDC_CUSTOMERCOMBO               1013
#define IDC_ORDERTYPECOMBO              1014
#define IDC_STOPPRICEBOX                1015
#define IDC_EDIT1                       1016
#define IDC_ORDERBOOKBOX                1016
#define IDC_STATUSBAR                   1017
#define IDC_WARNING                     1018
#define IDC_CHK_XTRADER                 1019
#define IDC_CHK_XTAPI                   1020
#define IDC_CHK_SELL                    1021
#define IDC_CHK_BUY                     1022
#define IDC_CHK_CONTRACT                1023
#define IDC_CHK_EXCHANGE                1024
#define IDC_SELECTORBUTTON              1025
#define IDC_RAD_ALLREQUIRED             1026
#define IDC_RADIO2                      1027
#define IDC_RAD_ALLOWANY                1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
