//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TTOrderSelector.rc
//
#define IDD_ORDERUPDATE_DIALOG			102
#define IDR_MAINFRAME                   128
#define IDC_EXCHANGEBOX                 1000
#define IDC_PRODUCTBOX                  1001
#define IDC_PRODTYPEBOX                 1002
#define IDC_CONTRACTBOX                 1003
#define IDC_PRICEBOX                    1005
#define IDC_QUANTITYBOX                 1006
#define IDC_BUYBUTTON                   1007
#define IDC_SELLBUTTON                  1008
#define IDC_CUSTOMERCOMBO               1013
#define IDC_ORDERSTATUSBOX              1016
#define IDC_STATUSBAR                   1017
#define IDC_WARNING                     1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
