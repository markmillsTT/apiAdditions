// {{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PriceUpdateDragDrop.rc
#define IDD_PRICEUPDATEDRAGDROP_DIALOG  102
#define IDR_MAINFRAME                   128
#define IDC_BIDQTYBOX                   1000
#define IDC_CONNECT                     1001
#define IDC_BIDBOX                      1002
#define IDC_ASKBOX                      1003
#define IDC_ASKQTYBOX                   1005
#define IDC_LASTBOX                     1006
#define IDC_LASTQTYBOX                  1007
#define IDC_LASTQTYCHGBOX               1008
#define IDC_EDIT2                       1009
#define IDC_STATUSBAR                   1009
#define IDC_CHECKBID                    1010
#define IDC_EXCHANGEBOX                 1011
#define IDC_PRODUCTBOX                  1012
#define IDC_PRODTYPEBOX                 1013
#define IDC_CONTRACTBOX                 1014
#define IDC_CHECK2                      1015
#define IDC_CHECKLTP                    1015
#define IDC_WARNING                     1016
