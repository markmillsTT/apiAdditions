//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MarketExplorer.rc
//
#define IDD_MARKETEXPLORER_DIALOG		101
#define IDR_MAINFRAME                   102
#define IDC_TXT_STATUSBAR               1014
#define IDC_BTN_MEAPI                   1015
#define IDC_BTN_REQUESTGATEWAYS         1015
#define IDC_WARNING                     1019
#define IDC_LB_GATEWAYS                 1021
#define IDC_LB_PRODUCTTYPES             1022
#define IDC_TREE1                       1023
#define IDC_TREE_PRODUCTS               1023
#define IDC_LB_INFO                     1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
