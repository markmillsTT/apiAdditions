//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TTPriceUpdate.rc
//
#define IDD_TTPRICEUPDATE_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_BIDQTYBOX                   1000
#define IDC_CONNECT                     1001
#define IDC_BIDBOX                      1002
#define IDC_BIDBOX1                     1002
#define IDC_ASKBOX                      1003
#define IDC_ASKBOX1                     1003
#define IDC_BIDBOX2                     1004
#define IDC_ASKQTYBOX                   1005
#define IDC_LASTBOX                     1006
#define IDC_LASTBOX1                    1006
#define IDC_LASTQTYBOX                  1007
#define IDC_LASTQTYCHGBOX               1008
#define IDC_EDIT2                       1009
#define IDC_STATUSBAR                   1009
#define IDC_CHECKBID                    1010
#define IDC_EXCHANGEBOX                 1011
#define IDC_EXCHANGEBOX1                1011
#define IDC_PRODUCTBOX                  1012
#define IDC_PRODUCTBOX1                 1012
#define IDC_PRODTYPEBOX                 1013
#define IDC_PRODTYPEBOX1                1013
#define IDC_CONTRACTBOX                 1014
#define IDC_CONTRACTBOX1                1014
#define IDC_CHECK2                      1015
#define IDC_CHECKLTP                    1015
#define IDC_WARNING                     1016
#define IDC_ASKBOX2                     1018
#define IDC_LASTBOX2                    1019
#define IDC_EXCHANGEBOX2                1020
#define IDC_PRODUCTBOX2                 1021
#define IDC_PRODTYPEBOX2                1022
#define IDC_CONTRACTBOX2                1023
#define IDC_BIDBOX3                     1024
#define IDC_ASKBOX3                     1025
#define IDC_LASTBOX3                    1026
#define IDC_EXCHANGEBOX3                1027
#define IDC_PRODUCTBOX3                 1028
#define IDC_PRODTYPEBOX3                1029
#define IDC_CONTRACTBOX3                1030
#define IDC_BIDBOX4                     1031
#define IDC_ASKBOX4                     1032
#define IDC_LASTBOX4                    1033
#define IDC_EXCHANGEBOX4                1034
#define IDC_PRODUCTBOX4                 1035
#define IDC_PRODTYPEBOX4                1036
#define IDC_CONTRACTBOX4                1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
