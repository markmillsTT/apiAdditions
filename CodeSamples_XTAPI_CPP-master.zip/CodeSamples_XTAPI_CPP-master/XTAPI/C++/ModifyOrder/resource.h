//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ModifyOrder.rc
//
#define IDD_TTModifyOrder_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_EXCHANGEBOX                 1001
#define IDC_PRODUCTBOX                  1002
#define IDC_PRODTYPEBOX                 1003
#define IDC_CONTRACTBOX                 1004
#define IDC_PRICEBOX                    1005
#define IDC_QTYBOX                      1006
#define IDC_NEWPRICEBOX                 1007
#define IDC_NEWQTYBOX                   1008
#define IDC_LOWPRICEBOX                 1009
#define IDC_HIGHPRICEBOX                1010
#define IDC_SOKBOX                      1011
#define IDC_SELLBUTTON                  1012
#define IDC_BUYBUTTON                   1013
#define IDC_MODIFYBUTTON                1014
#define IDC_DELETEBUTTON                1015
#define IDC_CUSTOMERCOMBO               1016
#define IDC_MODIFYTYPECOMBO             1017
#define IDC_DELETEORDERCOMBO            1018
#define IDC_BUYSELLCOMBO                1019
#define IDC_INCLUDERADIO                1020
#define IDC_EXCLUDERADIO                1021
#define IDC_GBINSTR                     1022
#define IDC_GBORDER                     1023
#define IDC_GBLASTORDER                 1024
#define IDC_GBMODIFYORDER               1025
#define IDC_GBDELETEORDER               1026
#define IDC_STATUSBAR                   1027
#define IDC_COMBOBOXEX1                 1028
#define IDC_COMBO1                      1029
#define IDC_WARNING                     1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
