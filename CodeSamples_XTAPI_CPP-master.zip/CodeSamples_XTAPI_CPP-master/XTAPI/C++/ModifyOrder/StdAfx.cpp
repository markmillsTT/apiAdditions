/// <summary>
/// stdafx.cpp : source file that includes just the standard includes
///	ModifyOrder.pch will be the pre-compiled header
///	stdafx.obj will contain the pre-compiled type information
/// </summary>
#include "stdafx.h"



