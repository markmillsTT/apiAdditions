//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PriceUpdateDepth.rc
//
#define IDD_TTPRICEUPDATE_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_BIDQTYBOX                   1000
#define IDC_CONNECT                     1001
#define IDC_BIDBOX                      1002
#define IDC_ASKBOX                      1003
#define IDC_COMBOBIDDEPTH               1004
#define IDC_ASKQTYBOX                   1005
#define IDC_LASTBOX                     1006
#define IDC_COMBOASKDEPTH               1007
#define IDC_CHKENABLEDEPTH              1008
#define IDC_BIDDEPTHLIST                1009
#define IDC_ASKDEPTHLIST                1010
#define IDC_EXCHANGEBOX                 1011
#define IDC_PRODUCTBOX                  1012
#define IDC_PRODTYPEBOX                 1013
#define IDC_CONTRACTBOX                 1014
#define IDC_EDIT1                       1015
#define IDC_STATUSBAR                   1015
#define IDC_WARNING                     1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
