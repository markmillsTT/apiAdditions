//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MonitorGateways.rc
//
#define IDD_MONITORGATEWAYS_DIALOG      101
#define IDR_MAINFRAME                   102
#define IDC_CBO_AVAILABLEGATEWAYS       1001
#define IDC_CHK_OPENPRICE               1002
#define IDC_CHK_OPENORDER               1003
#define IDC_CHK_OPENFILL                1004
#define IDC_BTN_CONNECT                 1005
#define IDC_TXT_ONEXCHANGESTATEUPDATE   1006
#define IDC_TXT_ONSTATUSUPDATE          1007
#define IDC_TXT_ONEXCHANGEMESSAGE       1008
#define IDC_TXT_PRICECONNECTION         1009
#define IDC_TXT_ORDERCONNECTION         1010
#define IDC_TXT_FILLCONNECTION          1011
#define IDC_TXT_XTRADER                 1012
#define IDC_TXT_XTRADERPRO              1013
#define IDC_TXT_STATUSBAR               1014
#define IDC_WARNING                     1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
